



local AbnormalDataCheckTableBase



return AbnormalDataCheckTableBase